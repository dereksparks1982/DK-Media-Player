DK Media Player – selected Design 4 icon.
Contains Cyrillic ДК lettering, red and gold Soviet-inspired cinema motif.
Use dk-media-player-512.png as master app icon; dk-media-player-180.png for Apple touch icon; dk-media-player-192.png and 512 for PWA manifest; favicon.ico for browser icon.
No repository changes are included.
